#!/bin/bash

SERVER="localhost"
USER="root"
PASSWD="root123"

GREP=`which grep`
ECHO=`which echo`
MYSQL=`which mysql`
MYSQL_BASE_CMD="${MYSQL} -u${USER} -p${PASSWD}"

DBSCRIPTS="`pwd`/dbscripts/"

# For all DBs

DBS="userstore billing bps rss_db shopping_cart_db appserver_config bps_config brs_config bam_config cep_config dss_config esb_config gadget_config identity_config manager_config mb_config mashup_config governance"

#DBS="userstore billing bps rss_db shopping_cart_db"
#DBS="appserver_config bps_config brs_config bam_config cep_config dss_config esb_config gadget_config identity_config manager_config mb_config mashup_config governance"

# Creating DBs

for D in ${DBS}; do 
	# Create
	${ECHO} -en "\n Creating ${D} .. "
	${MYSQL_BASE_CMD} "-e CREATE DATABASE ${D};"
	[ $? == 0 ] && ${ECHO} "[DONE]" || ${ECHO} "[FAILED]"
done

# Updating config DBs
CONFIG_DBS="appserver_config bps_config brs_config bam_config cep_config dss_config esb_config gadget_config identity_config manager_config mb_config mashup_config governance"

for D in ${CONFIG_DBS}; do
	${ECHO} -en "\n Updating ${D} .. "
	${MYSQL_BASE_CMD} ${D} < ${DBSCRIPTS}/registry.sql
	[ $? == 0 ] && ${ECHO} "[DONE]" || ${ECHO} "[FAILED]"
done

# Updating Userstore
${ECHO} -en "\n Updating userstore .. "
${MYSQL_BASE_CMD} userstore < ${DBSCRIPTS}/userstore.sql
[ $? == 0 ] && ${ECHO} "[DONE]" || ${ECHO} "[FAILED]"

# Updating billing
${ECHO} -en "\n Updating billing .. "
${MYSQL_BASE_CMD} billing < ${DBSCRIPTS}/billing_mysql.sql
${MYSQL_BASE_CMD} billing < ${DBSCRIPTS}/billing_bam.sql
${MYSQL_BASE_CMD} billing < ${DBSCRIPTS}/billing_metering.sql
[ $? == 0 ] && ${ECHO} "[DONE]" || ${ECHO} "[FAILED]"

# Updating BPS
${ECHO} -en "\n Updating bps .. "
${MYSQL_BASE_CMD} bps < ${DBSCRIPTS}/bps.sql
[ $? == 0 ] && ${ECHO} "[DONE]" || ${ECHO} "[FAILED]"

# Updating RSS_DB
${ECHO} -en "\n Updating rss_db .. "
${MYSQL_BASE_CMD} rss_db < ${DBSCRIPTS}/rss_db.sql
[ $? == 0 ] && ${ECHO} "[DONE]" || ${ECHO} "[FAILED]"

# Updating Shopping_Cart_DB
${ECHO} -en "\n Updating shopping_cart_db .. "
${MYSQL_BASE_CMD} shopping_cart_db < ${DBSCRIPTS}/shopping_cart_db.sql
[ $? == 0 ] && ${ECHO} "[DONE]" || ${ECHO} "[FAILED]"

# Creating user accounts and grants
${ECHO} -en "\n Creating user accounts and grants .. "
${MYSQL_BASE_CMD} < ${DBSCRIPTS}/users_grants.sql
[ $? == 0 ] && ${ECHO} "[DONE]" || ${ECHO} "[FAILED]"

exit $?

